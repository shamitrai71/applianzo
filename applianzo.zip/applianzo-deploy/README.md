# Applianzo

Country-aware Amazon kitchen discovery site. Searches Amazon India, US, and UK via the PA-API, with editorial content stored in Neon (PostgreSQL).

## Project structure

```
applianzo/
├── index.html                        # Frontend (single page app)
├── netlify.toml                      # Netlify build + redirect config
├── package.json                      # Dependencies
├── .env.example                      # Environment variable template
├── .gitignore
├── applianzo-neon-seed.sql           # DB schema + seed data — run once in Neon
└── netlify/
    └── functions/
        └── api.js                    # Single merged function (all routes)
```

## API endpoints (all handled by `api.js`)

| Endpoint | Description |
|---|---|
| `/.netlify/functions/api/categories?country=in` | Category list from Neon |
| `/.netlify/functions/api/search?country=in&q=air+fryer` | Amazon PA-API search |
| `/.netlify/functions/api/product?country=in&asin=B0XXXXXXXXX` | Product detail + editorial |

## Deploy checklist

### 1 — Neon database
1. Create a free project at [neon.tech](https://neon.tech)
2. Open the **SQL Editor**
3. Paste the contents of `applianzo-neon-seed.sql` and run it
4. Replace the three `REPLACE_WITH_YOUR_*_TAG` placeholders with your real Amazon Associates tags before running, **or** update them afterwards with a second SQL statement
5. Copy your **connection string** — it starts with `postgresql://...`

### 2 — Amazon PA-API credentials
1. Sign in to [Amazon Associates](https://affiliate-program.amazon.com)
2. Go to **Tools → Product Advertising API**
3. Note your **Access Key**, **Secret Key**, and your Associate tags for each marketplace (India tag ends in `-21`, US ends in `-20`, UK ends in `-21`)

### 3 — GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/applianzo.git
git push -u origin main
```

### 4 — Netlify
1. Go to [app.netlify.com](https://app.netlify.com) → **Add new site → Import from Git**
2. Choose your GitHub repo
3. Build settings are auto-detected from `netlify.toml` — no changes needed
4. Go to **Site settings → Environment variables** and add all variables below
5. Trigger a deploy

### 5 — Environment variables (add in Netlify)

| Variable | Value |
|---|---|
| `AMAZON_ACCESS_KEY` | Your PA-API access key |
| `AMAZON_SECRET_KEY` | Your PA-API secret key |
| `AMAZON_TAG_IN` | India Associates tag e.g. `yourtag-21` |
| `AMAZON_TAG_US` | US Associates tag e.g. `yourtag-20` |
| `AMAZON_TAG_UK` | UK Associates tag e.g. `yourtag-21` |
| `NEON_DATABASE_URL` | Your Neon connection string |
| `ALLOWED_ORIGIN` | Your Netlify URL e.g. `https://applianzo.netlify.app` |

### 6 — Test after deploy
```
https://your-site.netlify.app/.netlify/functions/api/categories?country=in
https://your-site.netlify.app/.netlify/functions/api/search?country=in&q=air+fryer
```

## Local development

```bash
cp .env.example .env
# Fill in your real values in .env
npm install -g netlify-cli   # install CLI globally (once)
npm install
netlify dev
```

## Before launch — mandatory
- [ ] Replace all `REPLACE_WITH_YOUR_*_TAG` placeholders in the SQL seed with real Associate tags
- [ ] Set `ALLOWED_ORIGIN` to your actual Netlify URL (not `*`)
- [ ] Add real ASINs + editorial content to the `editorial_content` table in Neon
- [ ] Create `/privacy` and `/terms` pages (linked in the footer)
- [ ] Verify the affiliate disclosure bar is visible on all pages
