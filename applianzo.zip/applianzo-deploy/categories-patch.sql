-- Applianzo — Home & Kitchen comprehensive categories migration
-- Run in Neon SQL Editor. Safe to re-run (upsert).

-- ── Add group column to categories if it doesn't exist ──────────────────────
alter table categories add column if not exists
  group_name text not null default 'Kitchen Appliances';

alter table categories add column if not exists
  search_index text not null default 'Kitchen';

-- ── Clear old sparse seed data and replace with full set ────────────────────
delete from categories;

-- ════════════════════════════════════════════════════════════════════
--  INDIA  (country_code = 'in')
-- ════════════════════════════════════════════════════════════════════
insert into categories (country_code, group_name, name, slug, search_keyword, search_index) values

-- Kitchen Appliances
('in','Kitchen Appliances','Air Fryers',          'air-fryers',           'air fryer',                  'Kitchen'),
('in','Kitchen Appliances','Mixer Grinders',       'mixer-grinders',       'mixer grinder',              'Kitchen'),
('in','Kitchen Appliances','Microwave Ovens',      'microwave-ovens',      'microwave oven',             'Kitchen'),
('in','Kitchen Appliances','Induction Cooktops',   'induction-cooktops',   'induction cooktop',          'Kitchen'),
('in','Kitchen Appliances','OTG Ovens',            'otg-ovens',            'OTG oven',                   'Kitchen'),
('in','Kitchen Appliances','Electric Kettles',     'electric-kettles',     'electric kettle',            'Kitchen'),
('in','Kitchen Appliances','Rice Cookers',         'rice-cookers',         'electric rice cooker',       'Kitchen'),
('in','Kitchen Appliances','Hand Blenders',        'hand-blenders',        'hand blender',               'Kitchen'),
('in','Kitchen Appliances','Juicers',              'juicers',              'juicer mixer grinder',       'Kitchen'),
('in','Kitchen Appliances','Sandwich Makers',      'sandwich-makers',      'sandwich maker',             'Kitchen'),
('in','Kitchen Appliances','Pressure Cookers',     'pressure-cookers',     'electric pressure cooker',   'Kitchen'),
('in','Kitchen Appliances','Coffee Makers',        'coffee-makers',        'coffee maker machine',       'Kitchen'),
('in','Kitchen Appliances','Food Processors',      'food-processors',      'food processor',             'Kitchen'),
('in','Kitchen Appliances','Water Purifiers',      'water-purifiers',      'water purifier RO',          'Kitchen'),
('in','Kitchen Appliances','Dishwashers',          'dishwashers',          'dishwasher',                 'Kitchen'),

-- Cookware & Bakeware
('in','Cookware & Bakeware','Cookware Sets',       'cookware-sets',        'non-stick cookware set',     'Kitchen'),
('in','Cookware & Bakeware','Non-stick Pans',      'non-stick-pans',       'non-stick frying pan',       'Kitchen'),
('in','Cookware & Bakeware','Pressure Cooker Sets','pressure-cooker-sets', 'stainless steel pressure cooker', 'Kitchen'),
('in','Cookware & Bakeware','Tawa & Griddles',     'tawa-griddles',        'iron tawa griddle',          'Kitchen'),
('in','Cookware & Bakeware','Kadai & Woks',        'kadai-woks',           'kadai iron wok',             'Kitchen'),
('in','Cookware & Bakeware','Bakeware Sets',       'bakeware-sets',        'baking tray set oven',       'Kitchen'),
('in','Cookware & Bakeware','Casseroles',          'casseroles',           'casserole dish',             'Kitchen'),

-- Kitchen Tools & Utensils
('in','Kitchen Tools & Utensils','Knife Sets',     'knife-sets',           'kitchen knife set',          'Kitchen'),
('in','Kitchen Tools & Utensils','Cutting Boards', 'cutting-boards',       'cutting chopping board',     'Kitchen'),
('in','Kitchen Tools & Utensils','Kitchen Scales', 'kitchen-scales',       'digital kitchen weighing scale', 'Kitchen'),
('in','Kitchen Tools & Utensils','Peelers & Graters','peelers-graters',    'vegetable peeler grater',    'Kitchen'),
('in','Kitchen Tools & Utensils','Ladles & Spatulas','ladles-spatulas',    'steel ladle spatula set',    'Kitchen'),
('in','Kitchen Tools & Utensils','Mixing Bowls',   'mixing-bowls',         'stainless steel mixing bowl set', 'Kitchen'),
('in','Kitchen Tools & Utensils','Storage Containers','storage-containers', 'airtight food container set', 'Kitchen'),
('in','Kitchen Tools & Utensils','Colanders & Strainers','colanders',      'stainless steel colander strainer', 'Kitchen'),

-- Home Appliances
('in','Home Appliances','Vacuum Cleaners',         'vacuum-cleaners',      'vacuum cleaner',             'Appliances'),
('in','Home Appliances','Washing Machines',        'washing-machines',     'fully automatic washing machine', 'Appliances'),
('in','Home Appliances','Ceiling Fans',            'ceiling-fans',         'BLDC ceiling fan',           'Appliances'),
('in','Home Appliances','Air Purifiers',           'air-purifiers',        'HEPA air purifier',          'Appliances'),
('in','Home Appliances','Room Heaters',            'room-heaters',         'room heater',                'Appliances'),
('in','Home Appliances','Irons & Steamers',        'irons-steamers',       'steam iron',                 'Appliances'),
('in','Home Appliances','Air Coolers',             'air-coolers',          'desert air cooler',          'Appliances'),
('in','Home Appliances','Water Heaters',           'water-heaters',        'electric water heater geyser', 'Appliances'),

-- Home Improvement
('in','Home Improvement','Power Drills',           'power-drills',         'cordless power drill',       'Tools'),
('in','Home Improvement','LED Light Bulbs',        'led-bulbs',            'LED smart bulb',             'Lighting'),
('in','Home Improvement','Smart Plugs',            'smart-plugs',          'smart plug Wi-Fi',           'Electronics'),
('in','Home Improvement','Extension Boards',       'extension-boards',     'surge protector extension cord', 'Electronics'),
('in','Home Improvement','Curtains & Blinds',      'curtains-blinds',      'blackout curtains',          'HomeImprovement'),
('in','Home Improvement','Storage & Organisation', 'storage-organisation', 'home storage organizer',     'HomeImprovement'),
('in','Home Improvement','Bathroom Accessories',   'bathroom-accessories', 'bathroom accessories set',   'HomeImprovement'),
('in','Home Improvement','Doormats & Rugs',        'doormats-rugs',        'anti-slip doormat rug',      'HomeImprovement')

on conflict (country_code, slug) do update set
  group_name   = excluded.group_name,
  name         = excluded.name,
  search_keyword = excluded.search_keyword,
  search_index = excluded.search_index,
  updated_at   = now();

-- ════════════════════════════════════════════════════════════════════
--  UNITED STATES  (country_code = 'us')
-- ════════════════════════════════════════════════════════════════════
insert into categories (country_code, group_name, name, slug, search_keyword, search_index) values

-- Kitchen Appliances
('us','Kitchen Appliances','Air Fryers',           'air-fryers',           'air fryer',                  'Kitchen'),
('us','Kitchen Appliances','Instant Pots',         'instant-pots',         'instant pot pressure cooker','Kitchen'),
('us','Kitchen Appliances','Coffee Makers',        'coffee-makers',        'coffee maker drip',          'Kitchen'),
('us','Kitchen Appliances','Espresso Machines',    'espresso-machines',    'espresso machine',           'Kitchen'),
('us','Kitchen Appliances','Stand Mixers',         'stand-mixers',         'KitchenAid stand mixer',     'Kitchen'),
('us','Kitchen Appliances','Blenders',             'blenders',             'high speed blender',         'Kitchen'),
('us','Kitchen Appliances','Toasters',             'toasters',             'toaster oven',               'Kitchen'),
('us','Kitchen Appliances','Microwave Ovens',      'microwave-ovens',      'countertop microwave',       'Kitchen'),
('us','Kitchen Appliances','Electric Kettles',     'electric-kettles',     'electric kettle',            'Kitchen'),
('us','Kitchen Appliances','Rice Cookers',         'rice-cookers',         'rice cooker',                'Kitchen'),
('us','Kitchen Appliances','Food Processors',      'food-processors',      'food processor',             'Kitchen'),
('us','Kitchen Appliances','Slow Cookers',         'slow-cookers',         'slow cooker crock pot',      'Kitchen'),
('us','Kitchen Appliances','Waffle Makers',        'waffle-makers',        'waffle maker',               'Kitchen'),
('us','Kitchen Appliances','Dishwashers',          'dishwashers',          'portable countertop dishwasher', 'Kitchen'),

-- Cookware & Bakeware
('us','Cookware & Bakeware','Cookware Sets',       'cookware-sets',        'stainless steel cookware set', 'Kitchen'),
('us','Cookware & Bakeware','Cast Iron Skillets',  'cast-iron-skillets',   'cast iron skillet',          'Kitchen'),
('us','Cookware & Bakeware','Non-stick Pans',      'non-stick-pans',       'non-stick frying pan',       'Kitchen'),
('us','Cookware & Bakeware','Dutch Ovens',         'dutch-ovens',          'enameled cast iron dutch oven', 'Kitchen'),
('us','Cookware & Bakeware','Bakeware Sets',       'bakeware-sets',        'bakeware set nonstick',      'Kitchen'),
('us','Cookware & Bakeware','Sheet Pans',          'sheet-pans',           'half sheet baking pan',      'Kitchen'),
('us','Cookware & Bakeware','Roasting Pans',       'roasting-pans',        'roasting pan with rack',     'Kitchen'),

-- Kitchen Tools & Utensils
('us','Kitchen Tools & Utensils','Knife Sets',     'knife-sets',           'chef knife set',             'Kitchen'),
('us','Kitchen Tools & Utensils','Cutting Boards', 'cutting-boards',       'bamboo cutting board',       'Kitchen'),
('us','Kitchen Tools & Utensils','Kitchen Scales', 'kitchen-scales',       'digital kitchen scale',      'Kitchen'),
('us','Kitchen Tools & Utensils','Measuring Cups', 'measuring-cups',       'measuring cups and spoons set', 'Kitchen'),
('us','Kitchen Tools & Utensils','Mixing Bowls',   'mixing-bowls',         'stainless steel mixing bowl set', 'Kitchen'),
('us','Kitchen Tools & Utensils','Storage Containers','storage-containers', 'food storage container set', 'Kitchen'),
('us','Kitchen Tools & Utensils','Can Openers',    'can-openers',          'electric can opener',        'Kitchen'),
('us','Kitchen Tools & Utensils','Mandoline Slicers','mandoline-slicers',  'mandoline slicer',           'Kitchen'),

-- Home Appliances
('us','Home Appliances','Robot Vacuums',           'robot-vacuums',        'robot vacuum cleaner',       'Appliances'),
('us','Home Appliances','Air Purifiers',           'air-purifiers',        'HEPA air purifier',          'Appliances'),
('us','Home Appliances','Humidifiers',             'humidifiers',          'cool mist humidifier',       'Appliances'),
('us','Home Appliances','Space Heaters',           'space-heaters',        'space heater',               'Appliances'),
('us','Home Appliances','Dehumidifiers',           'dehumidifiers',        'dehumidifier',               'Appliances'),
('us','Home Appliances','Clothes Steamers',        'clothes-steamers',     'garment steamer',            'Appliances'),
('us','Home Appliances','Ceiling Fans',            'ceiling-fans',         'ceiling fan with light',     'Appliances'),
('us','Home Appliances','Window AC Units',         'window-ac',            'window air conditioner',     'Appliances'),

-- Home Improvement
('us','Home Improvement','Smart Home Devices',     'smart-home',           'Amazon Echo smart home',     'Electronics'),
('us','Home Improvement','Smart Plugs',            'smart-plugs',          'smart plug outlet',          'Electronics'),
('us','Home Improvement','LED Strip Lights',       'led-strip-lights',     'LED strip lights',           'Lighting'),
('us','Home Improvement','Power Tools',            'power-tools',          'cordless drill combo kit',   'Tools'),
('us','Home Improvement','Storage & Shelving',     'storage-shelving',     'wall mounted shelving unit', 'HomeImprovement'),
('us','Home Improvement','Bathroom Accessories',   'bathroom-accessories', 'bathroom accessories set',   'HomeImprovement'),
('us','Home Improvement','Doormats & Rugs',        'doormats-rugs',        'washable area rug',          'HomeImprovement'),
('us','Home Improvement','Surge Protectors',       'surge-protectors',     'surge protector power strip','Electronics')

on conflict (country_code, slug) do update set
  group_name   = excluded.group_name,
  name         = excluded.name,
  search_keyword = excluded.search_keyword,
  search_index = excluded.search_index,
  updated_at   = now();

-- ════════════════════════════════════════════════════════════════════
--  UNITED KINGDOM  (country_code = 'uk')
-- ════════════════════════════════════════════════════════════════════
insert into categories (country_code, group_name, name, slug, search_keyword, search_index) values

-- Kitchen Appliances
('uk','Kitchen Appliances','Air Fryers',           'air-fryers',           'air fryer',                  'Kitchen'),
('uk','Kitchen Appliances','Kettles',              'kettles',              'electric kettle',            'Kitchen'),
('uk','Kitchen Appliances','Toasters',             'toasters',             'toaster 4 slice',            'Kitchen'),
('uk','Kitchen Appliances','Coffee Machines',      'coffee-machines',      'bean to cup coffee machine', 'Kitchen'),
('uk','Kitchen Appliances','Microwave Ovens',      'microwave-ovens',      'microwave oven',             'Kitchen'),
('uk','Kitchen Appliances','Food Processors',      'food-processors',      'food processor',             'Kitchen'),
('uk','Kitchen Appliances','Stand Mixers',         'stand-mixers',         'stand mixer',                'Kitchen'),
('uk','Kitchen Appliances','Blenders',             'blenders',             'power blender',              'Kitchen'),
('uk','Kitchen Appliances','Slow Cookers',         'slow-cookers',         'slow cooker',                'Kitchen'),
('uk','Kitchen Appliances','Instant Pots',         'instant-pots',         'instant pot multi cooker',   'Kitchen'),
('uk','Kitchen Appliances','Bread Makers',         'bread-makers',         'bread maker machine',        'Kitchen'),
('uk','Kitchen Appliances','Rice Cookers',         'rice-cookers',         'rice cooker',                'Kitchen'),
('uk','Kitchen Appliances','Mixer Grinders',       'mixer-grinders',       'mixer grinder',              'Kitchen'),
('uk','Kitchen Appliances','Dishwashers',          'dishwashers',          'slimline dishwasher',        'Kitchen'),

-- Cookware & Bakeware
('uk','Cookware & Bakeware','Cookware Sets',       'cookware-sets',        'non-stick cookware pan set', 'Kitchen'),
('uk','Cookware & Bakeware','Frying Pans',         'frying-pans',          'non-stick frying pan',       'Kitchen'),
('uk','Cookware & Bakeware','Casserole Dishes',    'casserole-dishes',     'cast iron casserole dish',   'Kitchen'),
('uk','Cookware & Bakeware','Bakeware Sets',       'bakeware-sets',        'bakeware set non-stick',     'Kitchen'),
('uk','Cookware & Bakeware','Roasting Tins',       'roasting-tins',        'roasting tin rack',          'Kitchen'),
('uk','Cookware & Bakeware','Woks',                'woks',                 'carbon steel wok',           'Kitchen'),

-- Kitchen Tools & Utensils
('uk','Kitchen Tools & Utensils','Knife Sets',     'knife-sets',           'kitchen knife set block',    'Kitchen'),
('uk','Kitchen Tools & Utensils','Cutting Boards', 'cutting-boards',       'wooden cutting board',       'Kitchen'),
('uk','Kitchen Tools & Utensils','Kitchen Scales', 'kitchen-scales',       'digital kitchen scales',     'Kitchen'),
('uk','Kitchen Tools & Utensils','Mixing Bowls',   'mixing-bowls',         'mixing bowl set',            'Kitchen'),
('uk','Kitchen Tools & Utensils','Storage Containers','storage-containers', 'food storage container set', 'Kitchen'),
('uk','Kitchen Tools & Utensils','Tin Openers',    'tin-openers',          'electric tin opener',        'Kitchen'),
('uk','Kitchen Tools & Utensils','Colanders',      'colanders',            'colander strainer',          'Kitchen'),

-- Home Appliances
('uk','Home Appliances','Vacuum Cleaners',         'vacuum-cleaners',      'cordless vacuum cleaner',    'Appliances'),
('uk','Home Appliances','Robot Vacuums',           'robot-vacuums',        'robot vacuum cleaner',       'Appliances'),
('uk','Home Appliances','Air Purifiers',           'air-purifiers',        'HEPA air purifier',          'Appliances'),
('uk','Home Appliances','Dehumidifiers',           'dehumidifiers',        'dehumidifier',               'Appliances'),
('uk','Home Appliances','Tumble Dryers',           'tumble-dryers',        'heat pump tumble dryer',     'Appliances'),
('uk','Home Appliances','Clothes Steamers',        'clothes-steamers',     'clothes steamer',            'Appliances'),
('uk','Home Appliances','Electric Blankets',       'electric-blankets',    'electric blanket',           'Appliances'),
('uk','Home Appliances','Heated Airers',           'heated-airers',        'heated clothes airer',       'Appliances'),

-- Home Improvement
('uk','Home Improvement','Smart Home Devices',     'smart-home',           'Amazon Echo smart speaker', 'Electronics'),
('uk','Home Improvement','Smart Plugs',            'smart-plugs',          'smart plug UK',              'Electronics'),
('uk','Home Improvement','LED Bulbs',              'led-bulbs',            'smart LED bulb E27',         'Lighting'),
('uk','Home Improvement','Power Drills',           'power-drills',         'cordless drill driver',      'Tools'),
('uk','Home Improvement','Storage & Shelving',     'storage-shelving',     'floating wall shelf',        'HomeImprovement'),
('uk','Home Improvement','Bathroom Accessories',   'bathroom-accessories', 'bathroom accessories chrome', 'HomeImprovement'),
('uk','Home Improvement','Doormats & Rugs',        'doormats-rugs',        'washable doormat rug',       'HomeImprovement'),
('uk','Home Improvement','Extension Leads',        'extension-leads',      'surge protected extension lead', 'Electronics')

on conflict (country_code, slug) do update set
  group_name   = excluded.group_name,
  name         = excluded.name,
  search_keyword = excluded.search_keyword,
  search_index = excluded.search_index,
  updated_at   = now();
